public class FiguraFactory {
    private static FiguraFactory instancia;

    public static FiguraFactory getInstance(){
        if (instancia==null)
            instancia= new FiguraFactory();
        return instancia;
    }

    private FiguraFactory(){

    }

    public Figura crearFigura(String tipo){
        switch (tipo){
            case "Rectangulo":
                return new Rectangulo();
            case "Triangulo":
                return new Triangulo();
            case "Circulo":
                return new Circulo();
            case "FiguraCompuesta":
                return new FiguraCompuesta();
            default:
                System.out.println("Error");
                return null;
        }
    }
}
