public class Trencito {

	public static void main(String[] args) {
		Figura rueda = FiguraFactory.getInstance().crearFigura("Circulo");
		((Circulo)rueda).setRadio(1);

		Figura cuerpoVagon=FiguraFactory.getInstance().crearFigura("Rectangulo");
		((Rectangulo)cuerpoVagon).setAlto(4);
		((Rectangulo)cuerpoVagon).setLargo(5);
		//Aclaración: En la consigna, los datos de la locomotora no son tan claros
		Figura baseChimenea=FiguraFactory.getInstance().crearFigura("Rectangulo");
		((Rectangulo)baseChimenea).setAlto(6);
		((Rectangulo)baseChimenea).setLargo(4);

		Figura cuerpoChimenea=FiguraFactory.getInstance().crearFigura("Rectangulo");
		((Rectangulo)cuerpoChimenea).setAlto(4);
		((Rectangulo)cuerpoChimenea).setLargo(3);

		Figura torreChimenea=FiguraFactory.getInstance().crearFigura("Rectangulo");
		((Rectangulo)torreChimenea).setAlto(1);
		((Rectangulo)torreChimenea).setLargo(1);

		Figura frenteLocomotora=FiguraFactory.getInstance().crearFigura("Triangulo");
		((Triangulo)frenteLocomotora).setBase(2);
		((Triangulo)frenteLocomotora).setAltura(2);
		
		Figura locomotora=FiguraFactory.getInstance().crearFigura("FiguraCompuesta");
		((FiguraCompuesta)locomotora).agregar(frenteLocomotora);
		((FiguraCompuesta)locomotora).agregar(rueda);
		((FiguraCompuesta)locomotora).agregar(rueda);
		((FiguraCompuesta)locomotora).agregar(baseChimenea);
		((FiguraCompuesta)locomotora).agregar(cuerpoChimenea);
		((FiguraCompuesta)locomotora).agregar(torreChimenea);

		System.out.println("Área Locomotora: "+locomotora.calcularArea());
		
		Figura primerVagon = FiguraFactory.getInstance().crearFigura("FiguraCompuesta");

		((FiguraCompuesta)primerVagon).agregar(rueda);
		((FiguraCompuesta)primerVagon).agregar(rueda);
		((FiguraCompuesta)primerVagon).agregar(rueda);
		((FiguraCompuesta)primerVagon).agregar(cuerpoVagon);

		System.out.println("Área Primer Vagón: "+primerVagon.calcularArea());

		Figura segundoVagon = FiguraFactory.getInstance().crearFigura("FiguraCompuesta");
		((FiguraCompuesta)segundoVagon).agregar(rueda);
		((FiguraCompuesta)segundoVagon).agregar(rueda);
		((FiguraCompuesta)segundoVagon).agregar(rueda);
		((FiguraCompuesta)segundoVagon).agregar(cuerpoVagon);

		System.out.println("Área Segundo Vagón: "+segundoVagon.calcularArea());
		
		Figura trencito = FiguraFactory.getInstance().crearFigura("FiguraCompuesta");
		((FiguraCompuesta)trencito).agregar(locomotora);
		((FiguraCompuesta)trencito).agregar(primerVagon);
		((FiguraCompuesta)trencito).agregar(segundoVagon);
		
		System.out.println("Área \uD83D\uDE82:"+trencito.calcularArea());


		

	}

}
