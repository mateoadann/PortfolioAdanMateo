package com.company;


import java.util.ArrayList;
import java.util.List;

public class PizzaCombinada extends Pizza{

    private List<Pizza> pizzas;

    public PizzaCombinada(String nombre, String descripcion) {
        super(nombre, descripcion);
        this.pizzas = new ArrayList<>();
    }

    public void agregar(Pizza pizza) {this.pizzas.add(pizza);}


    @Override
    public Double calcularPrecio() {
        Double precioFinal = 0.0;
        for (Pizza pizza : pizzas) {
            precioFinal += pizza.calcularPrecio();
        }
        precioFinal = precioFinal/ pizzas.size();
        return precioFinal ;
    }


}
