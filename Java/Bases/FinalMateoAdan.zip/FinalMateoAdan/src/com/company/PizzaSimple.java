package com.company;

public class PizzaSimple extends Pizza{
    private Double precioBase;
    private Boolean grande;

    public PizzaSimple(String nombre, String descripcion, Double precioBase, Boolean grande) {
        super(nombre, descripcion);
        this.precioBase = precioBase;
        this.grande = grande;
    }

    @Override
    public Double calcularPrecio() {
        Double precioFinal = 0.0;
        if (grande){
            precioFinal = precioBase*2;
            System.out.println(precioFinal);
        }else{
            precioFinal = precioBase;
            System.out.println(precioFinal);
        }
        return precioFinal;
    }
}
