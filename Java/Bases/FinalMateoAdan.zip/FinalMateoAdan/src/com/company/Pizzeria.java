package com.company;

import java.util.ArrayList;
import java.util.List;

public class Pizzeria {
    private List<Pizza> pizzas;

    public Pizzeria(){pizzas = new ArrayList<>();}
    public void agregarPizzas(String tipo){
        try {
             pizzas.add(PizzeriaFactory.getInstance().mostrarPizzas(tipo));
        }catch (PizzaException e){
            System.out.println(e.getMessage());
        }
    }
    public void mostrarTodasLasPizzas(){
        for (Pizza pizza : pizzas) {
            System.out.println(pizza);
        }
    }
}
