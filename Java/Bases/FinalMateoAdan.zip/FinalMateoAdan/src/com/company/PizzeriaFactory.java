package com.company;

import java.security.PublicKey;
import java.util.concurrent.RecursiveTask;

public class PizzeriaFactory {
    public static final String ANANA_CHICA = "ANANA-CHICA";
    public static final String ANANA_GRANDE = "ANANA-GRANDE";
    public static final String MUZZARELLA_CHICA = "MUZZARELLA-CHICA";
    public static final String MUZZARELLA_GRANDE = "MUZZARELLA-GRANDE";
    public static final String ESPECIAL_CHICA = "ESPECIAL-CHICA";
    public static final String ESPECIAL_GRANDE = "ESPECIAL-GRANDE";
    public static final String COMBINADA_LOCA_CHICA = "COMBINADA-LOCA-CHICA";
    public static final String COMBINADA_LOCA_GRANDE = "COMBINADA-LOCA-GRANDE";

    private static PizzeriaFactory instance;

    private PizzeriaFactory(){};

    public static PizzeriaFactory getInstance(){
        if(instance == null){
            instance = new PizzeriaFactory();
        }
        return instance;
    }

    public Pizza mostrarPizzas(String tipo) throws  PizzaException{
        switch (tipo){
            case ANANA_CHICA :
                return new PizzaSimple("ANANA-CHICA", "Pizza chiquita con mucho ananá.", 950.0, false);
            case ANANA_GRANDE :
                return new PizzaSimple("ANANA-GRANDE", "Pizza grande con mucho ananá.", 950.0, true);
            case MUZZARELLA_CHICA :
                return new PizzaSimple("MUZZARELLA-CHICA", "Pizza chiquita con mucha Muzzarella.", 700.0, false);
            case MUZZARELLA_GRANDE :
                return new PizzaSimple("MUZZARELLA-GRANDE", "Pizza grande con mucha Muzzarella.", 700.0, true);
            case ESPECIAL_CHICA :
                return new PizzaSimple("ESPECIAL-CHICA", "Pizza Especial chiquita.", 850.0, false);
            case ESPECIAL_GRANDE :
                return new PizzaSimple("ESPECIAL-GRANDE", "Pizza Especial grande.", 850.0, true);
            case COMBINADA_LOCA_CHICA:
                PizzaCombinada pizzaLocaChica =  new PizzaCombinada("COMBINADA-LOCA", "Mitad de un tipo, mitad de otro.");
                pizzaLocaChica.agregar(mostrarPizzas(ANANA_CHICA));
                pizzaLocaChica.agregar(mostrarPizzas(ESPECIAL_CHICA));
                return pizzaLocaChica;
            case COMBINADA_LOCA_GRANDE:
                PizzaCombinada pizzaLocaGrande =  new PizzaCombinada("COMBINADA-LOCA", "Mitad de un tipo, mitad de otro.");
                pizzaLocaGrande.agregar(mostrarPizzas(ANANA_GRANDE));
                pizzaLocaGrande.agregar(mostrarPizzas(ESPECIAL_GRANDE));
                return pizzaLocaGrande;

        }
        throw new PizzaException(tipo + " No tenemos ese tipo");
    };



}
