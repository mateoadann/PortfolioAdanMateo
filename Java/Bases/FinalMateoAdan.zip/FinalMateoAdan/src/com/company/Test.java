package com.company;

public class Test {

    public static void main(String[] args) {
	// write your code here
        Pizzeria pizzeria1 = new Pizzeria();

        pizzeria1.agregarPizzas(PizzeriaFactory.ANANA_GRANDE);

        pizzeria1.agregarPizzas(PizzeriaFactory.ANANA_CHICA);

        pizzeria1.agregarPizzas(PizzeriaFactory.MUZZARELLA_CHICA);

        pizzeria1.agregarPizzas(PizzeriaFactory.MUZZARELLA_GRANDE);
        pizzeria1.agregarPizzas(PizzeriaFactory.COMBINADA_LOCA_GRANDE);


        pizzeria1.mostrarTodasLasPizzas();
    }
}
