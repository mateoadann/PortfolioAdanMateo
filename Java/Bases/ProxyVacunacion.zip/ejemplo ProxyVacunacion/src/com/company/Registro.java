package com.company;

public interface Registro {
    public void registrar(Object[] datos);
}
