package com.dh.clinica.dao;

import java.util.List;

public interface IDao <T>{

    public Object registrar(T t);
    public List<T> listar();
}
