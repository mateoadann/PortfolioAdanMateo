package com.dh.clinica.service;

import com.dh.clinica.dao.IDao;
import com.dh.clinica.model.Odontologos;

import java.util.List;

public class OdontologosService {

    private IDao<Odontologos> odontologoIDao;

    public OdontologosService(IDao<Odontologos> odontologoIDao) {
        this.odontologoIDao = odontologoIDao;
    }

    public Odontologos registrar(Odontologos o){
        return (Odontologos) odontologoIDao.registrar(o);
    }
    public List<Odontologos> listar(){
        return odontologoIDao.listar();
    }


}
