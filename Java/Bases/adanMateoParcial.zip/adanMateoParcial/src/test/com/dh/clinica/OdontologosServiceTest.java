package test.com.dh.clinica;

import com.dh.clinica.dao.impl.OdontologoDaoH2;
import com.dh.clinica.model.Odontologos;
import com.dh.clinica.service.OdontologosService;

import org.junit.Assert;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;


import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class OdontologosServiceTest {

    private static OdontologosService odontologosService = new OdontologosService(new OdontologoDaoH2());


    @BeforeAll
    public static void cargarDataSet(){
        Odontologos o1 = odontologosService.registrar(new Odontologos(0005, "Rafa", "Nadal"));
        Odontologos o2 = odontologosService.registrar(new Odontologos(0006, "Checo", "Perez"));
    }

    @Test
    public void registrar() {
        Odontologos o1 = odontologosService.registrar(new Odontologos(0001, "Lionel", "Messi"));
        Odontologos o2 = odontologosService.registrar(new Odontologos(0002, "Papu", "Gomez"));

    }

    @Test
    public void listar() {
        List<Odontologos> odontologos = odontologosService.listar();
        Assert.assertTrue(!odontologos.isEmpty());
        Assert.assertTrue(odontologos.size()>0);
        System.out.println(odontologos);
    }
}