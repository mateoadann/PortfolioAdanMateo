package com.company;

import java.util.ArrayList;
import java.util.List;

public class Equipo {
    private String nombre;
    private List<Jugador> jugadores;


    public void equipo(String nombre){
        this.nombre = nombre;
        jugadores = new ArrayList<>();
        return;
    };
    public void agregarJugador(Jugador jugador){
        jugadores.add(jugador);
    }

    public void mostrarJugadoresTitulares(){
        for (Jugador jugador : jugadores){
            if (jugador.getEsTitular()){
                System.out.println(jugador);
            }
        }
    }


}
