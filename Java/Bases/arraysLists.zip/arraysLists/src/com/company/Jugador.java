package com.company;

public class Jugador implements Comparable<Jugador>{
    private Integer numeroCamiseta;
    private String nombre;
    private Boolean estaLesionado;
    private Boolean esTitular;

    public Jugador(Integer numeroCamiseta, String nombre, Boolean estaLesionado, Boolean esTitular) {
        this.numeroCamiseta = numeroCamiseta;
        this.nombre = nombre;
        this.estaLesionado = estaLesionado;
        this.esTitular = esTitular;
    }

    @Override
    public int compareTo(Jugador jugador) {



        return 0;
    }

    public String toString(){

    }


    public Boolean getEsTitular() {
        return esTitular;
    }
}
