package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here

        Equipo equipo = new Equipo();

        equipo.agregarJugador(new Jugador(30, "Messi", false, true));
        equipo.agregarJugador(new Jugador(1, "Dibu", false, false));
        equipo.agregarJugador(new Jugador(10, "Neymar", true, true));
        equipo.agregarJugador(new Jugador(5, "Gago", false, true));
        equipo.agregarJugador(new Jugador(8, "Di María", true, true));

    }
}
