package com.company;

public class Main {

    public static void main(String[] args) {

        Titulo CTD = new TituloTerciario(20,"01/03/2020","01/12/2022", true, true,false,false);
        Persona persona1 = new Persona("Mateo", "Adan", 44203014, 19, CTD);
        Titulo ingenieria = new TituloLicenciatura(25, "01/03/2021", "01/12/2024",true, true, "Presion del agua", "01/11/2024", 13);
        Persona persona2 = new Persona("Sol", "Andrade", 44502851, 18, ingenieria);
        Titulo arquitectura = new TituloLicenciatura(26, "01/03/2020","01/12/2022",true,true,"Columnas","01/08/2020", 11);


        System.out.println("Se puede ejercer o no");
        CTD.sePuedeEjercer();
        ingenieria.sePuedeEjercer();
        arquitectura.sePuedeEjercer();

        System.out.println();
        System.out.println("Compara con dos titulos de licenciatura");
        ingenieria.compareTo(arquitectura);

        System.out.println();
        System.out.println("Valida si el titulo terciario tiene validación Nacional");
        CTD.validacion();





    }
}
