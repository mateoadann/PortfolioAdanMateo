package com.company;

public class Persona {
    private String nombre;
    private String apellido;
    private Integer dni;
    private Integer edad;
    private Titulo titulo;

    public Persona(String nombre, String apellido, Integer dni, Integer edad, Titulo titulo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.edad = edad;
        this.titulo = titulo;
    }
}
