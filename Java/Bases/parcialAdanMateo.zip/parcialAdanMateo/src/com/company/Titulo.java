package com.company;

public abstract class Titulo {
    private Integer cantMaterias;
    private String fechaInicio;
    private String fechaFin;
    private Boolean selladoMinisterio;
    private Boolean selladoInstituto;


    public Titulo(Integer cantMaterias, String fechaInicio, String fechaFin, Boolean selladoMinisterio, Boolean selladoInstituto) {
        this.cantMaterias = cantMaterias;
        this.fechaInicio = fechaInicio;
        this.fechaFin = fechaFin;
        this.selladoMinisterio = selladoMinisterio;
        this.selladoInstituto = selladoInstituto;
    }

    public Boolean sePuedeEjercer(){
        if(getSelladoInstituto() && getSelladoMinisterio()){
            System.out.println("SI se puede ejercer con este título");
            return true;
        }else{
            System.out.println("NO se puede ejercer con este título");
            return false;
        }
    };

    public void validacion(){
    }

    public Boolean getSelladoMinisterio() {
        return selladoMinisterio;
    }

    public Boolean getSelladoInstituto() {
        return selladoInstituto;
    }

    public abstract int compareTo(Object object);
}
