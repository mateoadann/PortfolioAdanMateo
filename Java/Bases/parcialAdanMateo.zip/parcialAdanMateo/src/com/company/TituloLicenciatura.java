package com.company;

public class TituloLicenciatura extends Titulo{
        private String temaTesis;
        private String fechaEntregaTesis;
        private Integer cantTrabajosInvestigacion;

    public TituloLicenciatura(Integer cantMaterias, String fechaInicio, String fechaFin, Boolean selladoMinisterio, Boolean selladoInstituto, String temaTesis, String fechaEntregaTesis, Integer cantTrabajosInvestigacion) {
        super(cantMaterias, fechaInicio, fechaFin, selladoMinisterio, selladoInstituto);
        this.temaTesis = temaTesis;
        this.fechaEntregaTesis = fechaEntregaTesis;
        this.cantTrabajosInvestigacion = cantTrabajosInvestigacion;
    }
    @Override
    public int compareTo(Object object) {

        TituloLicenciatura otraLicenciatura = (TituloLicenciatura) object;

        if(this.cantTrabajosInvestigacion > otraLicenciatura.cantTrabajosInvestigacion){
            System.out.println("La primera carrera tiene MAS trabajos de investigacion. Ya que la segunda tiene: " + otraLicenciatura.cantTrabajosInvestigacion );
            return 1;
        }
        if(this.cantTrabajosInvestigacion < otraLicenciatura.cantTrabajosInvestigacion){
            System.out.println("La primera carrera tiene MENOS trabajos de investigacion. Ya que la segunda tiene: " + otraLicenciatura.cantTrabajosInvestigacion );
            return -1;
        }
        return 0;
    }

}
