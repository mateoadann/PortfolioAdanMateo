package com.company;

public class TituloTerciario extends Titulo{
    private Boolean validacionNacional;
    private Boolean validacionProvincial;

    public TituloTerciario(Integer cantMaterias, String fechaInicio, String fechaFin, Boolean selladoMinisterio, Boolean selladoInstituto, Boolean validacionNacional, Boolean validacionProvincial) {
        super(cantMaterias, fechaInicio, fechaFin, selladoMinisterio, selladoInstituto);
        this.validacionNacional = validacionNacional;
        this.validacionProvincial = validacionProvincial;
    }

    public Boolean validarNacional(){
        if(getValidacionNacional()){
            System.out.println("Este título tiene validación NACIONAL.");
            return true;
        }else{
            System.out.println("Este título NO tiene validación NACIONAL");
            return false;
        }
    };

    public Boolean getValidacionNacional() {
        return validacionNacional;
    }

    @Override
    public int compareTo(Object object) {
        return 0;
    }

    @Override
    public void validacion() {
        if (getValidacionNacional()){
            System.out.println("Este titulo SI tiene validación NACIONAL");
        }else{
            System.out.println("Este titulo NO tiene validación NACIONAL");
        }
    }
}
