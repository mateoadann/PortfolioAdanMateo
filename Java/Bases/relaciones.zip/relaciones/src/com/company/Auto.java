package com.company;

public class Auto {
    private String patente;
    private int anio;
    private String modelo;



    public Auto(String patente, int anio, String modelo){
        this.patente=patente;
        this.anio=anio;
        this.modelo=modelo;
    };

    //método
    public String getPatente(){
        return patente;
    }
    public void setPatente(String patente){
        this.patente=patente;
    };

}
