package com.company;

public class Computadora {

    private String marca;
    private String modelo;
    private int anioFabricacion;
    private Procesador procesador;
    private Disco disco;
    private Memoria memoria;

    public Computadora(String marca, String modelo, int anioFabricacion, Procesador procesador, Disco disco, Memoria memoria){
        this.marca=marca;
        this.modelo=modelo;
        this.anioFabricacion=anioFabricacion;
        this.memoria=memoria;
        this.memoria=memoria;
    }



}
