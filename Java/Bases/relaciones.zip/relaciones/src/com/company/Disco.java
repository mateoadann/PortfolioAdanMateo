package com.company;

public class Disco {
    private String marca;
    private Integer capacidad;
    private Integer velocidad;

    public Disco(String marca, Integer capacidad, Integer velocidad){
        this.marca=marca;
        this.capacidad=capacidad;
        this.velocidad=velocidad;
    }
}
