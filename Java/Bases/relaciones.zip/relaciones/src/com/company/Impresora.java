package com.company;

public class Impresora {
    private String modelo;
    private String tipoConexion;
    private String fechaDeFabricacion;
    private Integer hojasDisponibles;

    public Impresora(String modelo, String tipoConexion, String fechaDeFabricacion){
        this.modelo=modelo;
        this.tipoConexion=tipoConexion;
        this.fechaDeFabricacion=fechaDeFabricacion;
        this.hojasDisponibles=0;
    }

    public Impresora(String modelo, String tipoConexion){
        this.modelo=modelo;
        this.tipoConexion=tipoConexion;

    }

    private Boolean tienePapel(){
        return this.hojasDisponibles > 0;
    };

    public void imprimir(String texto){
        if (tienePapel()){
            System.out.println(texto);
            hojasDisponibles --;
        }else{
            System.out.println("No hay hojas disponibles");
        }
    }

    public void setHojasDisponibles(Integer hojasDisponibles) {
        this.hojasDisponibles = hojasDisponibles;
    }
}
