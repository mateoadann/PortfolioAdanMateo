package com.company;

public class Main {

    public static void main(String[] args) {
        /*Auto auto1;
        auto1 = new Auto("def456",1970,"Estanciera");
        System.out.println("La patente es: " + auto1.getPatente());
        auto1.setPatente("rup740");
        System.out.println("La patente nueva es: " + auto1.getPatente());
	    Chofer chofer1;
        chofer1 = new Chofer("Mateo", "Adan", auto1);
        System.out.println("La patente del auto del chofer1 es: " + chofer1.verpatente());*/

        /*Impresora impresora1;
        Impresora impresora2;
        impresora1 = new Impresora("HP", "Wifi", "10/10/2020");
        impresora2 = new Impresora("Epson","USB");

        impresora1.setHojasDisponibles(3);
        impresora1.imprimir("Hola, quiero imprimir esto....");
        impresora1.imprimir("Hola, quiero imprimir esto....");
        impresora1.imprimir("Hola, quiero imprimir esto....");
        impresora1.imprimir("Hola, quiero imprimir esto....");

        *//*impresora2.setHojasDisponibles(3);*//*
        impresora2.imprimir("Hola, quiero imprimir esto....(I2)");*/

        Perro perro1;
        perro1 = new Perro("pichicho", "Labrador", 2015, 10.0, true, false,true);
        System.out.println( perro1.getNombre() + " tiene " + perro1.consultarEdad() + " años.");

        System.out.println(perro1.factiblePerderse());
        System.out.println();





    }
}
