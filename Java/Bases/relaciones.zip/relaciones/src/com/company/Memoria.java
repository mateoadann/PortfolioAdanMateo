package com.company;

public class Memoria {
    private Integer capacidad;
    private String marca;

    public Memoria(Integer capacidad, String marca){
        this.capacidad=capacidad;
        this.marca=marca;
    }
}
