package com.company;

import java.nio.DoubleBuffer;

public class Perro {
    private String nombre;
    private String raza;
    private Integer anioNaciento;
    private Double pesoKg;
    private Boolean tieneChip;
    private Boolean estaLastimado;
    private Boolean estaEnAdopcion;


    public Perro(String nombre, String raza, Integer anioNaciento, Double pesoKg, Boolean tieneChip, Boolean estaLastimado, Boolean estaEnAdopcion) {
        this.nombre = nombre;
        this.raza = raza;
        this.anioNaciento = anioNaciento;
        this.pesoKg = pesoKg;
        this.tieneChip = tieneChip;
        this.estaLastimado = estaLastimado;
        this.estaEnAdopcion = estaEnAdopcion;
    }

    public Perro(String nombre, Double pesoKg, Boolean tieneChip, Boolean estaLastimado) {
        this.nombre = nombre;
        this.pesoKg = pesoKg;
        this.tieneChip = tieneChip;
        this.estaLastimado = estaLastimado;
    }

    //Métodos:

    public Integer consultarEdad(){
        Integer anioActual = 2022;
        return anioActual - this.anioNaciento;
    }

    public Boolean factiblePerderse(){
        return !this.tieneChip;
    }

    public Boolean enviarAdopcion(){
        if ((this.estaLastimado == false) && (this.pesoKg > 5.0)){
            return true;
        }
        else{
            return false;
        }
    }

    //getters y settters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public Integer getAnioNaciento() {
        return anioNaciento;
    }

    public void setAnioNaciento(Integer anioNaciento) {
        this.anioNaciento = anioNaciento;
    }

    public Double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(Double pesoKg) {
        this.pesoKg = pesoKg;
    }

    public Boolean getTieneChip() {
        return tieneChip;
    }

    public void setTieneChip(Boolean tieneChip) {
        this.tieneChip = tieneChip;
    }

    public Boolean getEstaLastimado() {
        return estaLastimado;
    }

    public void setEstaLastimado(Boolean estaLastimado) {
        this.estaLastimado = estaLastimado;
    }

    public Boolean getEstaEnAdopcion() {
        return estaEnAdopcion;
    }

    public void setEstaEnAdopcion(Boolean estaEnAdopcion) {
        this.estaEnAdopcion = estaEnAdopcion;
    }
}
