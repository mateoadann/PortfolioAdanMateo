package com.company;

public class Procesador {
    private String marca;
    private String modelo;
    private Double velocidad;


    public Procesador(String marca, String modelo, Double velocidad){
        this.marca=marca;
        this.modelo=modelo;
        this.velocidad=velocidad;
    }
}
